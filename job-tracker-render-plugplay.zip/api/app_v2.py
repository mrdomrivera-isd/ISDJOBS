#!/usr/bin/env python3
from __future__ import annotations
import os, time
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple

import requests
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from geopy.geocoders import Nominatim
from geopy.distance import geodesic

app = FastAPI(title="ID/Talent Job Finder API (pilot, no USAJOBS)", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS","*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Job(BaseModel):
    source: str
    company: str
    title: str
    location: str = ""
    remote: bool = False
    url: str
    department: Optional[str] = None
    work_type: Optional[str] = None
    posted_at: Optional[str] = None
    content_html: Optional[str] = None
    pay_type: Optional[str] = None
    comp_annual_min: Optional[float] = None
    comp_annual_max: Optional[float] = None

DEFAULT_KEYWORDS = [
    "instructional designer","instructional systems designer","learning experience",
    "learning designer","talent development","l&d","training",
    "technical training","training administration","technical trainer",
    "course developer","curriculum designer","training specialist",
    "learning and development"
]

DEFAULT_CLEARANCES = [
    "ts/sci","ts / sci","top secret","ts",
    "sci","ci poly","fs poly","full scope poly",
    "secret","public trust","security clearance"
]

HOURS_PER_YEAR = 2080.0

class SearchParams(BaseModel):
    zip: str = "20147"
    radius: float = 50
    include_remote: bool = True
    require_clearance: bool = True
    clearances: List[str] = Field(default_factory=lambda: DEFAULT_CLEARANCES)
    salary_min: float = 100000.0
    salary_max: float = 1000000.0
    pay_types: List[str] = Field(default_factory=lambda: ["hourly","salary"])
    keywords: List[str] = Field(default_factory=lambda: DEFAULT_KEYWORDS)
    companies_config: Optional[Dict[str, List[str]]] = None # {"lever":[], "greenhouse":[]}
    latitude: Optional[float] = None
    longitude: Optional[float] = None

class SearchResponse(BaseModel):
    results: List[Dict[str, Any]]
    meta: Dict[str, Any]

class BookmarkIn(BaseModel):
    url: str
    status: str = ""
    notes: str = ""

BOOKMARKS: Dict[str, Dict[str, Any]] = {}
CACHE: Dict[str, Any] = {}
CACHE_TTL = 90

def normalize(s: str) -> str:
    import re
    return re.sub(r"\s+"," ", (s or "")).strip()

def soup_text(html: Optional[str]) -> str:
    if not html: return ""
    try:
        return BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
    except Exception:
        return normalize(html)

def parse_money(s: str) -> Optional[float]:
    try:
        return float(str(s).replace(",","").strip())
    except Exception:
        return None

def to_annual_from_hourly(v: float) -> float:
    return v * HOURS_PER_YEAR

def extract_compensation_annual(text: str):
    import re
    t = text or ""
    money = r"\$?\s*([0-9]{2,3}(?:,[0-9]{3})*(?:\.[0-9]+)?)"
    sep = r"\s*(?:-|to|–|—)\s*"
    hr = re.search(money + sep + money + r"\s*/\s*(?:hr|hour)", t, re.I)
    if hr:
        lo = parse_money(hr.group(1)); hi = parse_money(hr.group(2))
        if lo and hi: return to_annual_from_hourly(min(lo,hi)), to_annual_from_hourly(max(lo,hi)), "hourly"
    hr1 = re.search(money + r"\s*/\s*(?:hr|hour)", t, re.I)
    if hr1:
        v = parse_money(hr1.group(1))
        if v: return to_annual_from_hourly(v), to_annual_from_hourly(v), "hourly"
    yr = re.search(money + sep + money + r"\s*/\s*(?:yr|year|annum|annually|per year)", t, re.I)
    if yr:
        lo = parse_money(yr.group(1)); hi = parse_money(yr.group(2))
        if lo and hi: return min(lo,hi), max(lo,hi), "salary"
    yr1 = re.search(money + r"\s*/\s*(?:yr|year|annum|annually|per year)", t, re.I)
    if yr1:
        v = parse_money(yr1.group(1))
        if v: return v, v, "salary"
    if re.search(r"\bhourly\b|\b/ ?hr\b", t, re.I):
        return None, None, "hourly"
    if re.search(r"\bsalary\b|\bper year\b", t, re.I):
        return None, None, "salary"
    return None, None, None

def title_matches(title: str, department: Optional[str], keywords: List[str]) -> bool:
    hay = f"{title} | {department or ''}".lower()
    return any(k.lower() in hay for k in keywords)

def clearance_matches(texts: List[str], allow_list: Optional[List[str]], require: bool) -> bool:
    joined = " | ".join((t or "").lower() for t in texts if t)
    if not require: return True
    keys = (allow_list or DEFAULT_CLEARANCES)
    return any(k.lower() in joined for k in keys)

def geocode_zip(zip_code: str):
    try:
        loc = Nominatim(user_agent="job_finder_pilot").geocode(zip_code)
        if loc: return (loc.latitude, loc.longitude)
    except Exception:
        pass
    return None

def fetch_lever(company: str) -> List[Job]:
    key = f"lever:{company}"
    now = time.time()
    if key in CACHE and now - CACHE[key]["ts"] < CACHE_TTL:
        return CACHE[key]["data"]
    url = f"https://api.lever.co/v0/postings/{company}?mode=json"
    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        print(f"[lever:{company}] error: {e}")
        return []
    out: List[Job] = []
    for item in data:
        title = normalize(item.get("text"))
        location = normalize((item.get("categories") or {}).get("location"))
        department = normalize((item.get("categories") or {}).get("team"))
        work_type = normalize((item.get("categories") or {}).get("commitment"))
        url_post = item.get("hostedUrl") or item.get("applyUrl")
        posted = item.get("createdAt")
        posted_iso = None
        if posted:
            try:
                posted_iso = datetime.utcfromtimestamp(int(posted)/1000).isoformat()
            except Exception:
                posted_iso = None
        content_html = item.get("description") or item.get("lists") or item.get("additional")
        blob = " | ".join([title, department or "", location or "", soup_text(content_html)])
        lo, hi, ptype = extract_compensation_annual(blob)
        out.append(Job(
            source="lever",
            company=company,
            title=title,
            location=location,
            remote="remote" in (location or "").lower(),
            url=url_post,
            department=department or None,
            work_type=work_type or None,
            posted_at=posted_iso,
            content_html=content_html if isinstance(content_html, str) else None,
            pay_type=ptype,
            comp_annual_min=lo,
            comp_annual_max=hi,
        ))
    CACHE[key] = {"ts": now, "data": out}
    return out

def fetch_greenhouse(company: str) -> List[Job]:
    key = f"greenhouse:{company}"
    now = time.time()
    if key in CACHE and now - CACHE[key]["ts"] < CACHE_TTL:
        return CACHE[key]["data"]
    url = f"https://boards-api.greenhouse.io/v1/boards/{company}/jobs?content=true"
    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        print(f"[greenhouse:{company}] error: {e}")
        return []
    out: List[Job] = []
    for item in data.get("jobs", []):
        title = normalize(item.get("title"))
        location = normalize((item.get("location") or {}).get("name"))
        dep = None
        if item.get("departments"):
            dep = ", ".join(d.get("name") for d in item.get("departments") if d.get("name"))
        work_type = None
        if item.get("metadata"):
            for m in item["metadata"]:
                if str(m.get("name")).lower() in {"employment type","employment_type","commitment"}:
                    work_type = normalize(m.get("value"))
                    break
        url_post = item.get("absolute_url")
        posted_iso = item.get("updated_at") or item.get("created_at")
        content_html = item.get("content")
        blob = " | ".join([title, dep or "", location or "", soup_text(content_html)])
        lo, hi, ptype = extract_compensation_annual(blob)
        out.append(Job(
            source="greenhouse",
            company=company,
            title=title,
            location=location,
            remote="remote" in (location or "").lower(),
            url=url_post,
            department=dep or None,
            work_type=work_type,
            posted_at=posted_iso,
            content_html=content_html,
            pay_type=ptype,
            comp_annual_min=lo,
            comp_annual_max=hi,
        ))
    CACHE[key] = {"ts": now, "data": out}
    return out

def collect_jobs(companies: Dict[str, List[str]], keywords: List[str]) -> List[Job]:
    jobs: List[Job] = []
    for c in companies.get("lever", []):
        jobs.extend(fetch_lever(c))
    for c in companies.get("greenhouse", []):
        jobs.extend(fetch_greenhouse(c))
    seen, out = set(), []
    for j in jobs:
        if j.url and j.url not in seen:
            seen.add(j.url)
            out.append(j)
    return out

def base_filters(jobs: List[Job], keywords: List[str], origin_zip: str, radius: float,
                 include_remote: bool, require_clearance: bool, allow_clearances: Optional[List[str]],
                 lat: Optional[float] = None, lon: Optional[float] = None) -> List[Job]:
    if lat is not None and lon is not None:
        origin = (lat, lon)
    else:
        origin = geocode_zip(origin_zip)
        if not origin:
            raise HTTPException(status_code=400, detail="Unable to geocode ZIP")
    kept: List[Job] = []
    geolocator = Nominatim(user_agent="job_finder_pilot_item")
    for j in jobs:
        if not title_matches(j.title, j.department, keywords):
            continue
        if not clearance_matches([j.title, j.department, j.location, soup_text(j.content_html)], allow_clearances, require_clearance):
            continue
        if include_remote and j.remote:
            kept.append(j); continue
        coords = None
        try:
            if j.location:
                loc = geolocator.geocode(j.location)
                if loc: coords = (loc.latitude, loc.longitude)
        except Exception:
            coords = None
        if not coords: continue
        if geodesic(origin, coords).miles <= radius:
            kept.append(j)
    return kept

@app.post("/search", response_model=SearchResponse)
async def search(params: SearchParams):
    companies = params.companies_config or {
        "lever": [],
        "greenhouse": ["andurilindustries","palantir","shieldai","hawkeye360","twosixtechnologies"],
    }
    all_jobs = collect_jobs(companies, params.keywords)
    kept = base_filters(all_jobs, params.keywords, params.zip, params.radius,
                        params.include_remote, params.require_clearance, params.clearances,
                        lat=params.latitude, lon=params.longitude)

    for j in kept:
        if j.comp_annual_min is None:
            blob = " | ".join([j.title, j.department or "", j.location or "", soup_text(j.content_html)])
            lo, hi, ptype = extract_compensation_annual(blob)
            j.comp_annual_min, j.comp_annual_max = lo, hi
            if not j.pay_type: j.pay_type = ptype

    def overlaps(j: Job) -> bool:
        lo = j.comp_annual_min
        hi = j.comp_annual_max if j.comp_annual_max is not None else lo
        if lo is None: return False
        if hi is None: hi = lo
        return (hi >= params.salary_min) and (lo <= params.salary_max)

    kept = [j for j in kept if overlaps(j)]
    rows = []
    for j in kept:
        rows.append({
            "source": j.source,
            "company": j.company,
            "title": j.title,
            "location": j.location,
            "remote": j.remote,
            "department": j.department or "",
            "work_type": j.work_type or "",
            "pay_type": j.pay_type or "",
            "comp_annual_min": j.comp_annual_min,
            "comp_annual_max": j.comp_annual_max,
            "posted_at": j.posted_at or "",
            "url": j.url,
            "bookmark_status": (BOOKMARKS.get(j.url) or {}).get("status",""),
            "bookmark_notes": (BOOKMARKS.get(j.url) or {}).get("notes",""),
            "bookmark_updated": (BOOKMARKS.get(j.url) or {}).get("updated_at",""),
        })
    rows.sort(key=lambda r: (-(r.get("comp_annual_min") or 0), r.get("posted_at") or "", r.get("company") or ""))
    return SearchResponse(results=rows, meta={"count": len(rows), "zip": params.zip, "radius": params.radius,
                                              "salary_min": params.salary_min, "salary_max": params.salary_max})

@app.get("/bookmarks")
async def list_bookmarks():
    return sorted(BOOKMARKS.values(), key=lambda x: x.get("updated_at",""), reverse=True)

@app.post("/bookmarks")
async def add_bookmark(bm: BookmarkIn):
    BOOKMARKS[bm.url] = {"url": bm.url, "status": bm.status, "notes": bm.notes,
                         "updated_at": datetime.utcnow().isoformat()}
    return BOOKMARKS[bm.url]

@app.patch("/bookmarks")
async def update_bookmark(bm: BookmarkIn):
    if bm.url not in BOOKMARKS:
        raise HTTPException(status_code=404, detail="Bookmark not found")
    rec = BOOKMARKS[bm.url]
    if bm.status is not None: rec["status"] = bm.status
    if bm.notes is not None: rec["notes"] = bm.notes
    rec["updated_at"] = datetime.utcnow().isoformat()
    return rec

@app.delete("/bookmarks")
async def delete_bookmark(bm: BookmarkIn):
    if bm.url in BOOKMARKS: del BOOKMARKS[bm.url]
    return {"ok": True}
